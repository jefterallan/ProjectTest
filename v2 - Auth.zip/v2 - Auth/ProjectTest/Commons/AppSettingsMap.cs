﻿namespace ProjectTest.Commons
{
    public class AppSettingsMap
    {
        public string FilePath { get; set; }
        public string FileName { get; set; }
        public string Delimiter { get; set; }
    }
}
