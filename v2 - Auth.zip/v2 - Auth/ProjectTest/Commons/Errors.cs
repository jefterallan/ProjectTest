﻿using System;

namespace ProjectTest.Commons
{
    public class Errors
    {
        public string ErrorMessage { get; set; }
    }
}
