﻿namespace ProjectTest.Data.Models.Enum
{
    public enum Genders
    {
        MALE = 1,
        FEMALE = 2
    }
}
