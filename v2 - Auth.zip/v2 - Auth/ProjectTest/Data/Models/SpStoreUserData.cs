﻿namespace ProjectTest.Data.Models
{
    public class SpStoreUserData
    {
        public string Result { get; set; }
    }
}
