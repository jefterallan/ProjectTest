﻿using ProjectTest.Data.Models;

namespace ProjectTest.Data.Repositories.Interfaces
{
    public interface IRepositoryBase<T> where T : class
    {
    }
}
